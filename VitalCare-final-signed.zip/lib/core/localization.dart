Map<String, Map<String, String>> translations = {'fr': {'appTitle':'VitalCare','welcome':'Bienvenue sur VitalCare'},'en': {'appTitle':'VitalCare','welcome':'Welcome to VitalCare'}};
